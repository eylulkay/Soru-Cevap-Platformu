    <footer>
        <p>Sherlock Siber Güvenlik Soru & Cevap Platformu, Telif Hakkı &copy; 2025</p>
    </footer>
</body>
</html>
