# Sherlock - Siber Güvenlik Soru & Cevap Platformu (MySQL/phpMyAdmin)

## Çalıştırma
- XAMPP/WAMP/Laragon ile Apache + MySQL/MariaDB çalıştırın
- phpMyAdmin üzerinden veritabanı adı: sherlock
- SQL tablolarını oluşturun (users, questions, faq)
- Proje klasörünü htdocs altına koyun
- Tarayıcı: http://localhost/sherlock_project/login.php

## Demo Admin
- Kullanıcı: admin
- Şifre: admin123

## Not
Bu sürüm SQLite yerine phpMyAdmin (MySQL/MariaDB) üzerinden PDO ile bağlanır.
